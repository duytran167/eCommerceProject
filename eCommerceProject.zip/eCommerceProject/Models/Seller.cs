﻿namespace eCommerceProject.Models
{
	public class Seller : ApplicationUser
	{
		

	}
}