﻿namespace eCommerceProject.Enums
{
	public enum EntityEnums
	{
		Post = 1,
		Blogs = 2,
		Pages = 3
	}
}