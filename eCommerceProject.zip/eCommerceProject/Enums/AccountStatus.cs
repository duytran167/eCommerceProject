﻿namespace eCommerceProject.Enums
{
	public enum AccountStatus
	{
		Active = 1,
		UnActive = 2,
		Disable = 3
	}
}